package unimunuto.edu;

import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author JpRo
 */
@Stateless
@Path("/ficha")
public class FactorialResource {

    /**
     *
     * @param orden
     * @return
     */
    @GET
    public String ficha(@QueryParam("movimiento") String orden) {

        return $ficha(orden);
    }

    String $ficha(String orden) {
        String resultado = "";
        if (orden.equalsIgnoreCase("traer")) {
            resultado = "X-0,5-X-X/X-1,5-X-X/2,4-2,5-X-X/X-X-X-X";
        } else if (orden.equalsIgnoreCase("girar")) {
            resultado = "0,4-0,5-0,6-X/X-X-1,6-X/X-X-X-X/X-X-X-X";
        } else if (orden.equalsIgnoreCase("izquierda")) {
            resultado = "X-0,3-X-X/X-1,3-X-X/2,2-2,3-X-X/X-X-X-X";
        } else if (orden.equalsIgnoreCase("derecha")) {
            resultado = "X-0,8-X-X/X-1,8-X-X/2,7-2,8-X-X/X-X-X-X";
        }
        return resultado;
    }
}
